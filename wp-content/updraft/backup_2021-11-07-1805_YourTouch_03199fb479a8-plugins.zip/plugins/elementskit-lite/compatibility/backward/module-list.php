<?php

namespace ElementsKit_Lite\Helpers;

defined('ABSPATH') || exit;

class Module_List extends \ElementsKit_Lite\Config\Module_List{
    //
}